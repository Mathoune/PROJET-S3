SLIDER deplace (int f, SLIDER S);
LISTE bouge(SLIDER s,LISTE l);
void partie(SLIDER S, char* nom, LISTE l);
