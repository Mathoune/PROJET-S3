SLIDER editeur(SLIDER S,int L,int H,char* nom);
