LISTE ajout (LISTE l, SLIDER S);
LISTE libere_liste (LISTE l);
LISTE supp_un_element (LISTE l);
LISTE retour_debut (LISTE l);
void libere_murs(SLIDER S);
LISTE retour (LISTE l, SLIDER S, int c);

