void ouvrir_dir (SLIDER S, LISTE l);
