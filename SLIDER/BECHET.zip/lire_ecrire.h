SLIDER init_slider(char *nom);

void ecrire_fichier(SLIDER S, char*nom);
